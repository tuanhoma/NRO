package nro.combine.ListCombine;

import nro.inventory.InventoryService;
import nro.player.Player;
import nro.services.Service;
import Utils.FormatStyle;
import Utils.Util;
import consts.ConstNpc;
import models.Item.Item;
import models.Item.ItemOption;
import models.Item.ItemService;
import nro.combine.CombineService;

public class TinhThachHoa {
 private static int getDaNangcapTinhThach(int star) {
        switch (star) {
            case 0:
                return 1;
            case 1:
                return 2;
            case 2:
                return 3;
            case 3:
                return 4;
            case 4:
                return 5;
            case 5:
                return 6;
            case 6:
                return 7;
            case 7:
                return 8;
        }
        return 0;
    }

    private static float getTiLeNangcapTinhThach(int star) {
        switch (star) {
            case 0:
                return 90f;
            case 1:
                return 50f;
            case 2:
                return 30f;
            case 3:
                return 25f;
            case 4:
                return 15f;
            case 5:
                return 8f;
            case 6:
                return 5f;
            case 7:
                return 2f;
        }
        return 0;
    }
    public static void showInfoCombine(Player player) {
    if (player.combine.itemsCombine.size() == 2) {
                    Item caiTrang = null;
                    Item manhVo = null;
                    int star = 0;
                    for (Item item : player.combine.itemsCombine) {
                       if (item.template.type == 21 || item.template.type == 72 || item.template.type == 11) {
                            caiTrang = item;
                        } else if (item.template.type == 93 && item.template.id >= 1711 && item.template.id <= 1717) {
                            manhVo = item;
                        }
                    }
                    if (caiTrang != null) {
                        for (ItemOption io : caiTrang.itemOptions) {
                            if (io.optionTemplate.id == 114||io.optionTemplate.id == 80||io.optionTemplate.id == 81||io.optionTemplate.id == 153||io.optionTemplate.id == 155||io.optionTemplate.id == 156||io.optionTemplate.id == 162) {
                                if (io.param >= CombineService.MAX_LEVEL_ITEM) {
                                    CombineService.gI().baHatMit.createOtherMenu(player, ConstNpc.IGNORE_MENU,
                                            "Vật phẩm đã nâng tinh thạch cấp tối đa", "Đóng");
                                    return;
                                }
                                star = io.param;
                                break;
                            }
                        }

                    }
                    player.combine.DaNangcap = getDaNangcapTinhThach(star);
                    player.combine.TileNangcap = getTiLeNangcapTinhThach(star);
                    if (caiTrang != null && manhVo != null) {
                        String npcSay = caiTrang.template.name + "\n|2|";
                        for (ItemOption io : caiTrang.itemOptions) {
                            npcSay += io.getOptionString() + "\n";
                        }
                        npcSay += "|7|Tỉ lệ thành công: " + getTiLeNangcapTinhThach(star) + "%" + "\n";
                        npcSay += "|1|Cần " + Util.formatNumber(getDaNangcapTinhThach(star), FormatStyle.VIETNAMESE) + " Tinh Thạch ";
                        CombineService.gI().baHatMit.createOtherMenu(player, ConstNpc.MENU_START_COMBINE, npcSay,
                                "Nâng cấp");

                    } else {
                        CombineService.gI().baHatMit.createOtherMenu(player, ConstNpc.IGNORE_MENU,
                                "Cần 1 Pet, Linh Thú hoặc Vật phẩm đeo lưng và loại đá tinh thạch", "Đóng");
                    }
                } else {
                    CombineService.gI().baHatMit.createOtherMenu(player, ConstNpc.IGNORE_MENU,
                            "Cần 1 Pet, Linh Thú hoặc Vật phẩm đeo lưng và loại đá tinh thạch", "Đóng");
                } }

    public static void startCombine(Player player) {
      float tiLe = player.combine.TileNangcap;

        if (player.combine.itemsCombine.size() == 2) {
            long gold = player.combine.goldCombine;
            if (player.inventory.gold < gold) {
                Service.gI().sendThongBao(player, "Không đủ vàng để thực hiện");
                return;
            }
            int gem = player.combine.gemCombine;
            if (player.inventory.gem < gem) {
                Service.gI().sendThongBao(player, "Không đủ ngọc để thực hiện");
                return;
            }

            Item caiTrang = null;
            Item manhCaiTrang = null;
            for (Item item : player.combine.itemsCombine) {
                if (item.template.type == 21 || item.template.type == 72 || item.template.type == 11) {
                    caiTrang = item;
                } else if (item.template.type == 93 && item.template.id >= 1711 && item.template.id <= 1717) {
                    manhCaiTrang = item;
                }
            }

            int star = 0;
            if (caiTrang != null) {
                for (ItemOption io : caiTrang.itemOptions) {
                    if (io.optionTemplate.id == 114||io.optionTemplate.id == 80||io.optionTemplate.id == 81||io.optionTemplate.id == 153||io.optionTemplate.id == 155||io.optionTemplate.id == 156||io.optionTemplate.id == 162) {
                        star = Math.max(star, io.param);
                    }
                }
            }
            if (star >= 10) {
                Service.gI().sendThongBao(player, "Đã max cấp");
                return;
            }
            if (caiTrang != null && manhCaiTrang != null && manhCaiTrang.quantity > player.combine.DaNangcap) {
                player.inventory.gold -= gold;
                player.inventory.gem -= gem;
                InventoryService.gI().subQuantityItemsBag(player, manhCaiTrang, player.combine.DaNangcap);
                if (Util.isTrue(tiLe, 100)) {
                    Item newCaiTrang = ItemService.gI().createNewItem((short) (caiTrang.template.id));

                    // Copy các chỉ số từ bông tai cũ sang bông tai mới
                    for (ItemOption io : caiTrang.itemOptions) {
                        newCaiTrang.itemOptions.add(new ItemOption(io.optionTemplate.id, io.param));
                    }

                    // Khai báo randomOptionId ở ngoài
                    int randomOptionId = -1;

                    // Xác định giá trị randomOptionId dựa trên manhCaiTrang.template.id
                    switch (manhCaiTrang.template.id) {
                        case 1711:
                            randomOptionId = 114;
                            break;
                        case 1712:
                            randomOptionId = 80;
                            break;
                        case 1713:
                            randomOptionId = 81;
                            break;
                        case 1714:
                            randomOptionId = 153;
                            break;
                        case 1715:
                            randomOptionId = 155;
                            break;
                        case 1716:
                            randomOptionId = 156;
                            break;
                        case 1717:
                            randomOptionId = 162;
                            break;
                        default:
                            break;
                    }

                    // Kiểm tra nếu newCaiTrang đã có loại tinh thạch khác
                    for (ItemOption io : newCaiTrang.itemOptions) {
                        if (io.optionTemplate.id != randomOptionId && (io.optionTemplate.id == 114||io.optionTemplate.id == 80||io.optionTemplate.id == 81||io.optionTemplate.id == 153||io.optionTemplate.id == 155||io.optionTemplate.id == 156||io.optionTemplate.id == 162)) {
                            Service.gI().sendThongBao(player, "Đã nâng một loại tinh thạch khác rồi, không thể nâng tiếp");
                            return;
                        }
                    }

                    // Nếu không có loại tinh thạch khác, tiếp tục thêm hoặc nâng cấp
                    boolean hasOption = false;
                    for (ItemOption io : newCaiTrang.itemOptions) {
                        if (io.optionTemplate.id == randomOptionId) {
                            io.param = Math.min(io.param + 1, CombineService.MAX_LEVEL_ITEM);
                            hasOption = true;
                            break;
                        }
                    }

                    if (!hasOption) {
                        newCaiTrang.itemOptions.add(new ItemOption(randomOptionId, 1));
                    }

                    CombineService.gI().sendEffectSuccessCombine(player);
                    InventoryService.gI().subQuantityItemsBag(player, caiTrang, 1);
                    InventoryService.gI().addItemBag(player, newCaiTrang);

                } else {
                    CombineService.gI().sendEffectFailCombine(player);
                }
                InventoryService.gI().sendItemBag(player);
                Service.gI().sendMoney(player);
                CombineService.gI().reOpenItemCombine(player);
            } else {
                Service.gI().sendThongBao(player, "Thiếu vật phẩm cần để nâng");
            }
        }
    }
    
}
