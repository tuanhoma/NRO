package nro.badges;

/*
 * Author Dev By Anwin
 */

public class BadgesTaskTemplate {

    public int id;
    public String name;
    public int count;
    public int idbadgesReward;

    public BadgesTaskTemplate() {
        id = -1;
        name = "";
        count = -1;
        idbadgesReward = -1;
    }
}






